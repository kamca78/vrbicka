﻿using System;

class Program
{
    static void Main()
    {
        Console.WriteLine("Vitejte v programu pro vypocet souctu zlomku!");

        try
        {
            Zlomek z1 = NactiZlomek("Zadejte prvni zlomek:");
            Zlomek z2 = NactiZlomek("Zadejte druhy zlomek:");
            Zlomek z3 = NactiZlomek("Zadejte treti zlomek:");

            Zlomek soucet = z1 + z2 + z3;

            Console.WriteLine($"Zlomek 1: {z1}, Zlomek 2: {z2}, Zlomek 3: {z3}");
            Console.WriteLine($"Soucet zlomku je: {soucet}");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Chyba: {ex.Message}");
        }
    }

    static Zlomek NactiZlomek(string prompt)
    {
        Console.WriteLine(prompt);

        Console.Write("Zadejte citatel: ");
        int citatel = int.Parse(Console.ReadLine());

        Console.Write("Zadejte jmenovatel (nenulovy): ");
        int jmenovatel = int.Parse(Console.ReadLine());

        if (jmenovatel == 0)
        {
            throw new ArgumentException("Jmenovatel nemuze byt nula.");
        }

        return new Zlomek(citatel, jmenovatel);
    }
}

class Zlomek
{
    public int Citatel { get; }
    public int Jmenovatel { get; }

    public Zlomek(int citatel, int jmenovatel)
    {
        Citatel = citatel;
        Jmenovatel = jmenovatel;
    }

    public static Zlomek operator +(Zlomek z1, Zlomek z2) =>
        new Zlomek(z1.Citatel * z2.Jmenovatel + z2.Citatel * z1.Jmenovatel, z1.Jmenovatel * z2.Jmenovatel);

    public override string ToString() => $"{Citatel}/{Jmenovatel}";
}